const botoes = document.querySelectorAll(".botao");
console.log(botoes);
